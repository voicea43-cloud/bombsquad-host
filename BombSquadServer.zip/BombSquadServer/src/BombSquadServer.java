import java.io.*;
import java.net.*;
import java.util.*;
import java.util.concurrent.*;
import java.text.SimpleDateFormat;

public class BombSquadServer {
    // ===== إعدادات السيرفر =====
    private static final int PORT = 29248;
    private static final String SERVER_IP = "157.180.102.182";
    private static final String ADMIN_ID = "pb-IF5dUBAKDg==";
    private static final int MAX_PLAYERS = 16;
    private static final String SERVER_NAME = "🎮 BOMBSQUAD ARABIC SERVER 🎮";
    
    // ===== قوائم اللاعبين =====
    public static Map<String, ClientHandler> players = new ConcurrentHashMap<>();
    public static Set<String> bannedPlayers = ConcurrentHashMap.newKeySet();
    public static Set<String> mutedPlayers  = ConcurrentHashMap.newKeySet();
    
    // ===== إحصائيات =====
    public static long startTime = System.currentTimeMillis();
    private static int totalConnections = 0;
    
    // ===== خرائط اللعبة =====
    private static String[] maps = {
        "Football Stadium", "Courtyard", "Doom Room",
        "Happy Thoughts", "Lake Frigid", "Rampage",
        "Step Right Up", "The Pad", "Tower D", "Zigzag"
    };
    public static String currentMap  = maps[0];
    public static String gameMode    = "free-for-all";

    // ===== نقطة البداية =====
    public static void main(String[] args) {
        printBanner();
        
        try (ServerSocket serverSocket = new ServerSocket(PORT)) {
            serverSocket.setSoTimeout(1000);
            System.out.println("✅ Server started on port " + PORT);
            System.out.println("👑 Admin ID: " + ADMIN_ID);
            System.out.println("🚫 Vote Kick: DISABLED");
            System.out.println("=".repeat(60));
            
            // موضوع التحكم عبر الكونسول
            new Thread(BombSquadServer::consoleHandler).start();
            
            // استقبال الاتصالات
            while (true) {
                try {
                    Socket clientSocket = serverSocket.accept();
                    if (players.size() < MAX_PLAYERS) {
                        totalConnections++;
                        new Thread(new ClientHandler(clientSocket)).start();
                    } else {
                        clientSocket.getOutputStream().write("Server is full!\n".getBytes());
                        clientSocket.close();
                    }
                } catch (SocketTimeoutException ignored) {}
            }
            
        } catch (IOException e) {
            System.err.println("❌ Server error: " + e.getMessage());
        }
    }

    // ===== طباعة اللافتة =====
    private static void printBanner() {
        System.out.println("=".repeat(60));
        System.out.println("🔥 " + SERVER_NAME + " 🔥");
        System.out.println("=".repeat(60));
        System.out.println("📡 IP:         " + SERVER_IP);
        System.out.println("🔌 Port:       " + PORT);
        System.out.println("👑 Admin:      " + ADMIN_ID);
        System.out.println("👥 MaxPlayers: " + MAX_PLAYERS);
        System.out.println("=".repeat(60));
    }

    // ===== معالج الكونسول =====
    private static void consoleHandler() {
        Scanner scanner = new Scanner(System.in);
        while (true) {
            try {
                System.out.print("\n🎮 Admin Console> ");
                String command = scanner.nextLine().trim().toLowerCase();
                
                switch (command) {
                    case "quit": case "exit":
                        System.out.println("🛑 Stopping server...");
                        broadcast("⚠️ Server is shutting down!");
                        System.exit(0);
                        break;
                    case "status":
                        printStatus();
                        break;
                    case "players":
                        listPlayers();
                        break;
                    case "maps":
                        listMaps();
                        break;
                    case "help":
                        printHelp();
                        break;
                    default:
                        if (command.startsWith("kick "))
                            kickPlayer(command.substring(5).trim());
                        else if (command.startsWith("ban "))
                            banPlayer(command.substring(4).trim());
                        else if (command.startsWith("unban "))
                            unbanPlayer(command.substring(6).trim());
                        else if (command.startsWith("mute "))
                            mutePlayer(command.substring(5).trim());
                        else if (command.startsWith("unmute "))
                            unmutePlayer(command.substring(7).trim());
                        else if (command.startsWith("say "))
                            broadcast("📢 ADMIN: " + command.substring(4));
                        else if (command.startsWith("map "))
                            changeMap(command.substring(4).trim());
                        else if (command.startsWith("mode "))
                            changeMode(command.substring(5).trim());
                        else if (!command.isEmpty())
                            System.out.println("❓ Unknown command. Type 'help'");
                }
            } catch (Exception e) {
                System.err.println("⚠️ Console error: " + e.getMessage());
            }
        }
    }

    private static void printStatus() {
        long uptime   = System.currentTimeMillis() - startTime;
        long hours    = uptime / 3600000;
        long minutes  = (uptime % 3600000) / 60000;
        long seconds  = (uptime % 60000) / 1000;
        System.out.println("\n📊 SERVER STATUS:");
        System.out.println("   • Players:     " + players.size() + "/" + MAX_PLAYERS);
        System.out.println("   • Map:         " + currentMap);
        System.out.println("   • Mode:        " + gameMode);
        System.out.println("   • Uptime:      " + hours + "h " + minutes + "m " + seconds + "s");
        System.out.println("   • Connections: " + totalConnections);
        System.out.println("   • Banned:      " + bannedPlayers.size());
        System.out.println("   • Muted:       " + mutedPlayers.size());
    }

    private static void listPlayers() {
        if (players.isEmpty()) { System.out.println("\n📭 No players online"); return; }
        System.out.println("\n👥 ONLINE PLAYERS (" + players.size() + "):");
        for (ClientHandler p : players.values()) {
            System.out.println("   " + (p.isAdmin() ? "👑 " : "") + (p.isMuted() ? "🔇 " : "") + p.getPlayerName() + "  [" + p.getPlayerId() + "]");
        }
    }

    private static void listMaps() {
        System.out.println("\n🗺️ AVAILABLE MAPS:");
        for (int i = 0; i < maps.length; i++)
            System.out.println("   " + (i + 1) + ". " + maps[i] + (maps[i].equals(currentMap) ? " ✅" : ""));
    }

    private static void kickPlayer(String name) {
        for (ClientHandler p : players.values())
            if (p.getPlayerName().equalsIgnoreCase(name)) {
                p.kick("Kicked by admin"); System.out.println("✅ Kicked " + name); return;
            }
        System.out.println("❌ Player not found: " + name);
    }

    private static void banPlayer(String name) {
        for (ClientHandler p : players.values())
            if (p.getPlayerName().equalsIgnoreCase(name)) {
                bannedPlayers.add(p.getPlayerId());
                saveBans();
                p.kick("Banned by admin");
                broadcast("🔨 " + name + " has been banned!");
                System.out.println("✅ Banned " + name); return;
            }
        System.out.println("❌ Player not found: " + name);
    }

    private static void unbanPlayer(String id) {
        if (bannedPlayers.remove(id)) {
            saveBans(); System.out.println("✅ Unbanned: " + id);
        } else {
            System.out.println("❌ ID not in ban list");
        }
    }

    private static void mutePlayer(String name) {
        for (ClientHandler p : players.values())
            if (p.getPlayerName().equalsIgnoreCase(name)) {
                mutedPlayers.add(p.getPlayerId());
                p.sendMessage("🔇 You have been muted by admin");
                System.out.println("✅ Muted " + name); return;
            }
        System.out.println("❌ Player not found: " + name);
    }

    private static void unmutePlayer(String name) {
        for (ClientHandler p : players.values())
            if (p.getPlayerName().equalsIgnoreCase(name)) {
                mutedPlayers.remove(p.getPlayerId());
                p.sendMessage("🔊 You have been unmuted");
                System.out.println("✅ Unmuted " + name); return;
            }
        System.out.println("❌ Player not found: " + name);
    }

    private static void changeMap(String mapName) {
        for (String m : maps)
            if (m.equalsIgnoreCase(mapName)) {
                currentMap = m;
                broadcast("🗺️ Map changed to: " + currentMap);
                System.out.println("✅ Map changed to: " + currentMap); return;
            }
        System.out.println("❌ Map not found. Use 'maps' to see list.");
    }

    private static void changeMode(String mode) {
        gameMode = mode;
        broadcast("🎮 Game mode changed to: " + gameMode);
        System.out.println("✅ Mode changed to: " + gameMode);
    }

    private static void printHelp() {
        System.out.println("""
            
            📚 ADMIN CONSOLE COMMANDS:
            ─────────────────────────────────────
            status          - Show server status
            players         - List online players
            maps            - List available maps
            kick [name]     - Kick a player
            ban [name]      - Ban a player
            unban [id]      - Unban a player by ID
            mute [name]     - Mute a player
            unmute [name]   - Unmute a player
            say [message]   - Broadcast a message
            map [name]      - Change current map
            mode [name]     - Change game mode
            quit / exit     - Stop server
            help            - Show this help
            ─────────────────────────────────────
            """);
    }

    // ===== حفظ وتحميل البان =====
    private static void saveBans() {
        try (PrintWriter pw = new PrintWriter("config/banned.txt")) {
            for (String id : bannedPlayers) pw.println(id);
        } catch (IOException e) {
            System.err.println("⚠️ Could not save bans: " + e.getMessage());
        }
    }

    public static void loadBans() {
        File f = new File("config/banned.txt");
        if (!f.exists()) return;
        try (BufferedReader br = new BufferedReader(new FileReader(f))) {
            String line;
            while ((line = br.readLine()) != null)
                if (!line.trim().isEmpty()) bannedPlayers.add(line.trim());
            System.out.println("📋 Loaded " + bannedPlayers.size() + " bans.");
        } catch (IOException e) {
            System.err.println("⚠️ Could not load bans: " + e.getMessage());
        }
    }

    // ===== Utilities =====
    public static void broadcast(String message) { broadcast(message, null); }

    public static void broadcast(String message, String excludeId) {
        for (ClientHandler p : players.values())
            if (!p.getPlayerId().equals(excludeId)) p.sendMessage(message);
    }

    public static boolean isBanned(String id)  { return bannedPlayers.contains(id); }
    public static boolean isMuted(String id)   { return mutedPlayers.contains(id); }
    public static boolean isAdmin(String id)   { return id.equals(ADMIN_ID); }
    public static void addPlayer(String id, ClientHandler h) { players.put(id, h); }
    public static void removePlayer(String id)               { players.remove(id); }
}
