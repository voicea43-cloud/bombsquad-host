import java.io.*;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * Logger - يسجل أحداث السيرفر في ملف logs/server.log
 */
public class Logger {
    private static final String LOG_FILE = "logs/server.log";
    private static final SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public static synchronized void log(String type, String message) {
        String entry = "[" + sdf.format(new Date()) + "] [" + type + "] " + message;
        System.out.println("📝 " + entry);
        try {
            File dir = new File("logs");
            if (!dir.exists()) dir.mkdirs();
            try (FileWriter fw = new FileWriter(LOG_FILE, true);
                 PrintWriter pw = new PrintWriter(fw)) {
                pw.println(entry);
            }
        } catch (IOException e) {
            System.err.println("⚠️ Logger error: " + e.getMessage());
        }
    }
}
