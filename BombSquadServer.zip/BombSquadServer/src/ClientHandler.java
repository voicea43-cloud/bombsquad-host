import java.io.*;
import java.net.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class ClientHandler implements Runnable {
    private Socket socket;
    private PrintWriter out;
    private BufferedReader in;
    private String playerId;
    private String playerName;
    private boolean isAdmin;
    private boolean muted;
    private long connectedTime;

    public ClientHandler(Socket socket) {
        this.socket        = socket;
        this.connectedTime = System.currentTimeMillis();
    }

    @Override
    public void run() {
        try {
            in  = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            out = new PrintWriter(socket.getOutputStream(), true);

            // توليد ID من IP + Port
            playerId   = socket.getInetAddress().getHostAddress() + ":" + socket.getPort();
            playerName = "Player_" + (System.currentTimeMillis() % 9999);
            isAdmin    = BombSquadServer.isAdmin(playerId);
            muted      = BombSquadServer.isMuted(playerId);

            // التحقق من الحظر
            if (BombSquadServer.isBanned(playerId)) {
                sendMessage("❌ You are banned from this server.");
                socket.close();
                return;
            }

            // تسجيل اللاعب
            BombSquadServer.addPlayer(playerId, this);

            // رسالة الترحيب
            sendWelcomeMessage();

            // إعلام الآخرين
            String joinMsg = isAdmin
                    ? "👑 ADMIN " + playerName + " has joined!"
                    : "👋 " + playerName + " joined the server!";
            System.out.println(isAdmin
                    ? "👑 Admin connected: " + socket.getInetAddress()
                    : "👤 Player connected: " + socket.getInetAddress());
            BombSquadServer.broadcast(joinMsg, playerId);

            // تسجيل في اللوج
            Logger.log("CONNECT", playerName + " [" + playerId + "]");

            // حلقة الاستقبال
            String inputLine;
            while ((inputLine = in.readLine()) != null) {
                handleMessage(inputLine.trim());
            }

        } catch (IOException ignored) {
        } finally {
            closeConnection();
        }
    }

    // ===== رسالة الترحيب =====
    private void sendWelcomeMessage() {
        long uptime  = System.currentTimeMillis() - BombSquadServer.startTime;
        long hours   = uptime / 3600000;
        long minutes = (uptime % 3600000) / 60000;

        sendMessage("╔══════════════════════════════════════╗");
        sendMessage("║     🎮  BOMBSQUAD ARABIC SERVER  🎮   ║");
        sendMessage("╠══════════════════════════════════════╣");
        sendMessage("║  Map    : " + padRight(BombSquadServer.currentMap, 27) + "║");
        sendMessage("║  Mode   : " + padRight(BombSquadServer.gameMode, 27) + "║");
        sendMessage("║  Players: " + padRight(BombSquadServer.players.size() + "/16", 27) + "║");
        sendMessage("║  Uptime : " + padRight(hours + "h " + minutes + "m", 27) + "║");
        sendMessage("╠══════════════════════════════════════╣");
        if (isAdmin) {
            sendMessage("║  👑 YOU ARE ADMIN!                    ║");
            sendMessage("║  /kick /ban /mute /say /map /status   ║");
        } else {
            sendMessage("║  Vote Kick : DISABLED                 ║");
            sendMessage("║  Type /help for commands              ║");
        }
        sendMessage("╚══════════════════════════════════════╝");
    }

    private String padRight(String s, int n) {
        return String.format("%-" + n + "s", s);
    }

    // ===== معالجة الرسائل =====
    private void handleMessage(String message) {
        if (message == null || message.isEmpty()) return;

        if (message.startsWith("/")) {
            handleCommand(message.substring(1));
        } else {
            if (muted || BombSquadServer.isMuted(playerId)) {
                sendMessage("🔇 You are muted.");
                return;
            }
            String prefix  = isAdmin ? "👑 ADMIN" : "💬";
            String chatMsg = prefix + " " + playerName + ": " + message;
            System.out.println(chatMsg);
            BombSquadServer.broadcast(chatMsg, playerId);
            Logger.log("CHAT", playerName + ": " + message);
        }
    }

    // ===== معالجة الأوامر =====
    private void handleCommand(String command) {
        String[] parts = command.split(" ", 2);
        String   cmd   = parts[0].toLowerCase();
        String   arg   = parts.length > 1 ? parts[1].trim() : "";

        switch (cmd) {
            case "help":
                sendHelp();
                break;

            case "players":
                sendPlayerList();
                break;

            case "time":
                sendMessage("⏱️ " + new SimpleDateFormat("HH:mm:ss").format(new Date()));
                break;

            case "status":
                sendStatus();
                break;

            case "kick":
                if (isAdmin && !arg.isEmpty()) adminKick(arg);
                else if (!isAdmin) sendMessage("❌ No permission.");
                break;

            case "ban":
                if (isAdmin && !arg.isEmpty()) adminBan(arg);
                else if (!isAdmin) sendMessage("❌ No permission.");
                break;

            case "mute":
                if (isAdmin && !arg.isEmpty()) adminMute(arg);
                else if (!isAdmin) sendMessage("❌ No permission.");
                break;

            case "unmute":
                if (isAdmin && !arg.isEmpty()) adminUnmute(arg);
                else if (!isAdmin) sendMessage("❌ No permission.");
                break;

            case "say":
                if (isAdmin && !arg.isEmpty())
                    BombSquadServer.broadcast("📢 ADMIN: " + arg);
                else if (!isAdmin) sendMessage("❌ No permission.");
                break;

            case "map":
                if (isAdmin && !arg.isEmpty()) adminChangeMap(arg);
                else sendMessage("Current map: " + BombSquadServer.currentMap);
                break;

            case "maps":
                sendMessage("🗺️ Maps: Football Stadium, Courtyard, Doom Room, Happy Thoughts, Lake Frigid, Rampage, Step Right Up, The Pad, Tower D, Zigzag");
                break;

            case "me":
                sendMessage("👤 Name: " + playerName + " | Admin: " + isAdmin);
                break;

            default:
                sendMessage("❓ Unknown command. Type /help");
        }
    }

    private void sendHelp() {
        if (isAdmin) {
            sendMessage("""
                📚 ADMIN COMMANDS:
                /kick [name]   - Kick player
                /ban [name]    - Ban player
                /mute [name]   - Mute player
                /unmute [name] - Unmute player
                /say [msg]     - Announce message
                /map [name]    - Change map
                /maps          - List maps
                /players       - List players
                /status        - Server status
                /time          - Server time
                /me            - Your info
                """);
        } else {
            sendMessage("""
                📚 COMMANDS:
                /players - List online players
                /time    - Server time
                /status  - Server status
                /maps    - Available maps
                /me      - Your info
                /help    - This help
                """);
        }
    }

    private void sendPlayerList() {
        StringBuilder sb = new StringBuilder("\n👥 Online (" + BombSquadServer.players.size() + "/16):\n");
        for (ClientHandler p : BombSquadServer.players.values()) {
            sb.append("  ").append(p.isAdmin() ? "👑 " : "").append(p.isMuted() ? "🔇 " : "").append(p.getPlayerName()).append("\n");
        }
        sendMessage(sb.toString());
    }

    private void sendStatus() {
        long uptime  = System.currentTimeMillis() - BombSquadServer.startTime;
        long hours   = uptime / 3600000;
        long minutes = (uptime % 3600000) / 60000;
        sendMessage("📊 Status | Players: " + BombSquadServer.players.size() + "/16 | Map: "
                + BombSquadServer.currentMap + " | Uptime: " + hours + "h " + minutes + "m");
    }

    // ===== أوامر الأدمن =====
    private void adminKick(String name) {
        for (ClientHandler p : BombSquadServer.players.values())
            if (p.getPlayerName().equalsIgnoreCase(name)) {
                p.kick("Kicked by admin");
                BombSquadServer.broadcast("🔨 " + name + " was kicked by admin.");
                sendMessage("✅ Kicked " + name);
                Logger.log("KICK", playerName + " kicked " + name);
                return;
            }
        sendMessage("❌ Player not found: " + name);
    }

    private void adminBan(String name) {
        for (ClientHandler p : BombSquadServer.players.values())
            if (p.getPlayerName().equalsIgnoreCase(name)) {
                BombSquadServer.bannedPlayers.add(p.getPlayerId());
                p.kick("Banned by admin");
                BombSquadServer.broadcast("🔨 " + name + " was banned.");
                sendMessage("✅ Banned " + name);
                Logger.log("BAN", playerName + " banned " + name);
                return;
            }
        sendMessage("❌ Player not found: " + name);
    }

    private void adminMute(String name) {
        for (ClientHandler p : BombSquadServer.players.values())
            if (p.getPlayerName().equalsIgnoreCase(name)) {
                BombSquadServer.mutedPlayers.add(p.getPlayerId());
                p.sendMessage("🔇 You have been muted.");
                sendMessage("✅ Muted " + name);
                return;
            }
        sendMessage("❌ Player not found: " + name);
    }

    private void adminUnmute(String name) {
        for (ClientHandler p : BombSquadServer.players.values())
            if (p.getPlayerName().equalsIgnoreCase(name)) {
                BombSquadServer.mutedPlayers.remove(p.getPlayerId());
                p.sendMessage("🔊 You have been unmuted.");
                sendMessage("✅ Unmuted " + name);
                return;
            }
        sendMessage("❌ Player not found: " + name);
    }

    private void adminChangeMap(String mapName) {
        String[] maps = {"Football Stadium","Courtyard","Doom Room","Happy Thoughts",
                "Lake Frigid","Rampage","Step Right Up","The Pad","Tower D","Zigzag"};
        for (String m : maps)
            if (m.equalsIgnoreCase(mapName)) {
                BombSquadServer.currentMap = m;
                BombSquadServer.broadcast("🗺️ Map changed to: " + m + " by admin");
                return;
            }
        sendMessage("❌ Map not found. Use /maps to see list.");
    }

    // ===== الإرسال والإغلاق =====
    public void sendMessage(String message) {
        if (out != null) out.println(message);
    }

    public void kick(String reason) {
        sendMessage("❌ You have been kicked: " + reason);
        closeConnection();
    }

    private void closeConnection() {
        try {
            BombSquadServer.removePlayer(playerId);
            BombSquadServer.broadcast("👋 " + playerName + " left the server.", playerId);
            System.out.println("👋 Left: " + playerName);
            Logger.log("DISCONNECT", playerName + " [" + playerId + "]");
            socket.close();
        } catch (IOException ignored) {}
    }

    // ===== Getters =====
    public String  getPlayerId()   { return playerId; }
    public String  getPlayerName() { return playerName; }
    public boolean isAdmin()       { return isAdmin; }
    public boolean isMuted()       { return muted || BombSquadServer.isMuted(playerId); }
}
