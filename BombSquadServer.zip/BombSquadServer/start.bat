@echo off
:: ======================================================
::  BombSquad Server - سكريبت تشغيل ويندوز
:: ======================================================

echo === BombSquad Arabic Server ===

:: إنشاء المجلدات
if not exist config mkdir config
if not exist logs mkdir logs
if not exist bin mkdir bin

:: تجميع الكود
echo [1/2] Compiling...
javac -d bin src\Logger.java src\ClientHandler.java src\BombSquadServer.java

if %errorlevel% neq 0 (
    echo Compilation failed!
    pause
    exit /b 1
)

echo [2/2] Starting server...
cd bin
java -cp . BombSquadServer
pause
