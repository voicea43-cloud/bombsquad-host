#!/bin/bash
# ======================================================
#  BombSquad Server - سكريبت التشغيل
#  استخدم هذا الملف لتشغيل السيرفر على أي لينكس / هوست
# ======================================================

GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m'

echo -e "${GREEN}=== BombSquad Arabic Server ===${NC}"

# إنشاء المجلدات إذا ما كانت موجودة
mkdir -p config logs bin

# ===== تجميع الكود =====
echo -e "${GREEN}[1/2] Compiling Java files...${NC}"
javac -d bin src/Logger.java src/ClientHandler.java src/BombSquadServer.java

if [ $? -ne 0 ]; then
    echo -e "${RED}❌ Compilation failed! Check Java files.${NC}"
    exit 1
fi

echo -e "${GREEN}✅ Compiled successfully!${NC}"

# ===== تشغيل السيرفر =====
echo -e "${GREEN}[2/2] Starting server...${NC}"
cd bin
java -cp . BombSquadServer

